g++ -I build/include/ -o test test.cpp build/lib/libhl++.a && ./test
